import React from 'react';
import Ctgr from './ctgr';
import './ctgrs.css';
export default function(){
    return(
        <div className="brnctgr">
        <h2>Our-Courses</h2>
        <div className="ctgr-col">
<Ctgr />
<Ctgr />
<Ctgr />
<Ctgr />
<Ctgr />
<Ctgr />
<Ctgr />
<Ctgr />
<Ctgr />
</div>
                <a href="#" className="buprod showmore">
                    <span>S</span>
                    <span>H</span>
                    <span>O</span>
                    <span>W</span>
                    <span>M</span>
                    <span>O</span>
                    <span>R</span>
                    <span>E</span>
                </a>
</div>
    );
}