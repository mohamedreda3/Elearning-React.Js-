import React from 'react';
import './ctgrs.css';

export default function(){
    return(
                <div className="oslide">
            <div className="image">
                <img src="../../cmpnts/images/mx.png" />
            </div>
            <div className="slideinfo">
                <h1 className="oname">Web-Development</h1>
                <p>The frontend of a software program or website is everything with which the user interacts.
                    From a user standpoint, the frontend is synonymous with the user interface.</p>
<strong><p>StudentsNumber : 1500 Student</p></strong>
<strong><p>(5.0)</p></strong>
                <a href="#" className="buprod">
                    <span>V</span>
                    <span>I</span>
                    <span>E</span>
                    <span>W</span>
                    <span>C</span>
                    <span>O</span>
                    <span>U</span>
                    <span>R</span>
                    <span>S</span>
                    <span>E</span>
                </a>
            </div>
        </div>
    );
}