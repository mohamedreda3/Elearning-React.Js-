import React from 'react';
import Hdr from '../cmpnts/hdr/hdr.jsx';
import './App.css';

function App() {
  return (
    <div>
      <Hdr />
    </div>
  );
}

export default App;